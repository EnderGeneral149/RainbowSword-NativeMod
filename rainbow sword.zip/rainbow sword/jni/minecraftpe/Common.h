#pragma once
#include <string>

class Common {
public:
	static std::string getGameVersionString();
	static std::string getGameDevVersionString();
	static std::string getGameVersionStringNet();
};
