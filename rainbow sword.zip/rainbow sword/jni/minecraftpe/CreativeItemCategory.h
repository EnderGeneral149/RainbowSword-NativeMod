#pragma once

enum class CreativeItemCategory : int
{
	Blocks = 1,
	Decorations,
	Tools,
	Items
};

