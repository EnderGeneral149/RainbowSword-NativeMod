#pragma once

#include <string>

class ColorFormat {
public:
	static std::string FromString(const std::string&);
};