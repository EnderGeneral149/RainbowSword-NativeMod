#pragma once

#include <string>

class Util {
public:
	static std::string toLower(const std::string&);
};