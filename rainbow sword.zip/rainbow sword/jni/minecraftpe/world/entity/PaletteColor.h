#pragma once

enum class PaletteColor : unsigned char
{
	WHITE,
	ORANGE,
	MAGENTA,
	LIGHTBLUE,
	YELLOW,
	LIME,
	PINK,
	GRAY,
	LIGHTGRAY,
	CYAN,
	PURPLE,
	BLUE,
	BROWN,
	GREEN,
	RED,
	BLACK
};
