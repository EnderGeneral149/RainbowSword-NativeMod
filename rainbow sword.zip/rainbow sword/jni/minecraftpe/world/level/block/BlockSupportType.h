#pragma once

enum class BlockSupportType : int
{
	
};
