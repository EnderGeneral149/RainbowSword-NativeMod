#pragma once

struct RectangleArea {
    float x, y, w, h;
};